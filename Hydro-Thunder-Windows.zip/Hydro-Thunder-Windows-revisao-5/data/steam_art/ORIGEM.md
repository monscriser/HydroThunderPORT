Capa publica de Hydro Thunder Hurricane, SteamGridDB jogo34946. Fonte: https://www.steamgriddb.com/game/34946
Imagem: https://cdn2.steamgriddb.com/thumb/d07ec5ea07081262d33991cea73c964c.jpg
