# Hydro Thunder Hurricane — revisao 5 experimental

Windows: abra Launcher-Config.exe para configurar ou HydroThunder.exe para jogar diretamente. Mantenha os dois arquivos e a pasta data juntos. Os componentes tecnicos ficam dentro de data.
Linux: abra HydroThunder-teste.AppImage. A abertura normal mostra o configurador; o atalho exportado para Steam inicia o jogo diretamente. Marque o AppImage como executavel nas propriedades se necessario.

## Reaproveitar seu jogo e saves
No configurador, clique em Usar pasta do jogo existente e selecione a pasta da instalacao anterior que contem game_data e user_data. Nao copie o jogo para a nova build. Uma pasta ja preparada com Base.apf e default.xex compativel pode ser usada diretamente. O registro de caminho fica em APPDATA/HydroThunderRecompiled no Windows e XDG_DATA_HOME/HydroThunderRecompiled ou ~/.local/share/HydroThunderRecompiled no Linux.
Os saves continuam em user_data dentro da pasta do jogo registrada. Atualizar a build nao move nem apaga essa pasta. Nao apague a pasta da instalacao anterior enquanto ela for a pasta de dados registrada. Para move-la, mova os seus dados e selecione o novo local. Ha botoes para exportar/importar saves.
Pacotes originais ainda precisam de preparacao/extracao uma unica vez na pasta de dados escolhida; o processo preserva os pacotes originais e prepara o update0.0.2.1. Futuras builds reutilizam a pasta registrada.

## Video
Idioma, contador FPS opcional(desligado por padrao), Async, FSR1, limite de FPS e modo de exibicao ficam na aba Video e idioma. Clique Jogar para salvar e aplicar; o configurador fecha e abre o jogo com essas configuracoes.
FSR1 espacial EASU/RCAS amplia a imagem720p para uma saida maior; em tamanho nativo aplica nitidez CAS. Nao e FSR3 nem geracao de quadros. Nao ha promessa de ganho de FPS. Saidas720p/1080p/1440p/2160p ajustam a janela/apresentacao; nao representam renderizacao interna4K. Sem bordas usa a resolucao do desktop. Tela cheia solicita um modo do monitor e pode usar sem bordas se indisponivel.
Limites60/120/240 sao tetos de apresentacao do guest; o relogio original permanece60Hz. Nao desbloqueiam120/240quadros nativos nem aceleram a fisica.
A resolucao do jogo agora independe do tamanho compacto do configurador, para preservar16:9. Apresentacao FIFO limita trabalho repetido de exibicao; o ganho no Ally ainda precisa ser medido.

## Steam e cache
Feche a Steam completamente, clique Adicionar a Steam e escolha a conta. O exportador preserva os demais atalhos e guarda backup do arquivo anterior. Inclui uma capa publica do SteamGridDB jogo34946; fonte em steam_art/ORIGEM.md. A Steam deve permanecer fechada durante a exportacao. No Linux, mantenha o AppImage no local definitivo antes de exportar.
Cache de shaders existente na pasta do jogo e reutilizado quando disponivel; caso contrario fica na pasta persistente de configuracao. Limpar shadercache remove somente os arquivos de shader/pipeline deste titulo, preservando saves. Feche o jogo antes de limpar. A recompilacao inicial pode voltar a causar engasgos.

## Estado real
Windows e Linux compilados. AppImage: configurador e execucao direta testados; FSR1 EASU/RCAS confirmados em Vulkan/Linux; imagem 1080p em 16:9 e dados/saves externos sem nova copia. O teste Linux usou WSL/llvmpipe, nao o Ally. No Windows foram testados entrada na corrida com Start/A, aceleracao em RT, pausa, saida ao menu e reabertura com cache existente. A pasta do pacote contem dois executaveis e uma pasta data.
As luzes de portais atravessando paredes continuam pendentes de uma correcao comprovada. O desempenho relatado de 30 FPS no Ally ainda nao foi retestado com esta revisao. Nao se promete 60/120 FPS ou ausencia absoluta de engasgos. A limpeza automatica de RAM/VRAM e o FSR3 estao adiados por pedido do usuario. Esta entrega encerra a rodada de trabalho no prazo solicitado, preservando essas pendencias.

Enter=Start; Espaco=A; E=RT/acelerar; WASD/setas=direcao; Backspace=B. Player1/Player2 locais definidos automaticamente. DLC/update e conteudo comprado preservados. Nao inclui dados originais do jogo, DLC, update ou saves. Licencas em licenses.
